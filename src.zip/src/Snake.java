public class Snake {

    public static void main(String[] args) {

        new GameFrame();
    }
}
